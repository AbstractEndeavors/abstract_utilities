from .imports import *
# -------- Public API drop-ins that mirror your originals --------
from .filter_params import *
from .file_filters import *
# -------------------------------------------------------------
# Wrapper: respects your original API and naming conventions
# -------------------------------------------------------------
def get_normalized(items, recursive=True, allowed=None, fs=None, **kwargs):
    if fs is None:
        # if no backend provided, normalize
        normalized = normalize_items(items, **kwargs)
    else:
        normalized = [(fs, item, {}) for item in make_list(items)]
    return normalized
def get_allowed_predicate(allowed=None):
    if allowed is not False:
        if allowed is True:
            allowed = None
        allowed = allowed or make_allowed_predicate()
    else:
        def allowed(*args):
            return True
    return allowed


# -------------------------------------------------------------
# Remote-aware globbing
# -------------------------------------------------------------
def get_globs(
    items,
    recursive: bool = True,
    allowed=None,
    fs=None,
    include_dirs=True,
    include_files=True,
    exclude_hidden=False,
    follow_symlinks=False,
    mindepth: int = 0,
    **kwargs,
):
    """
    Seamless local/remote version of your globbing logic.
    - Includes top-level files when mindepth == 0.
    - Uses normalize_items() only once.
    - Calls backend glob_recursive() for remote systems, and glob.glob() for local.
    """
    glob_paths: List[str] = []
    allowed = get_allowed_predicate(allowed)

    # Normalize: local and remote paths resolved here
    normalized = get_normalized(items, recursive=recursive, allowed=allowed, fs=fs, **kwargs)

    for fs, base, _ in normalized:
        # Remote or local depending on fs type
        if isinstance(fs, SSHFS):
            # use remote find via fs.glob_recursive
            nuItems = fs.glob_recursive(
                base,
                mindepth=mindepth,
                follow_symlinks=follow_symlinks,
                include_dirs=include_dirs,
                include_files=include_files,
                exclude_hidden=exclude_hidden,
            )
            input(nuItems)
        else:
            # local fallback uses Python's glob module
            patterns = []
            if mindepth == 0:
                patterns.append(os.path.join(base, "*"))
            if recursive:
                patterns.append(os.path.join(base, "**", "*"))

            nuItems: List[str] = []
            for pattern in patterns:
                nuItems.extend(glob.glob(pattern, recursive=recursive))

        # optional filter
        if allowed:
            nuItems = [p for p in nuItems if p and allowed(p,fs)]

        glob_paths.extend(nuItems)
    
    return glob_paths


# -------------------------------------------------------------
# Allowed filters
# -------------------------------------------------------------
def get_allowed_files(items, allowed=True, **kwargs):
    items = make_root_list(items)
    allowed = get_allowed_predicate(allowed=allowed)
    out = []
    for fs, item, _ in normalize_items(items, **kwargs):
        if fs.isfile(item) and allowed(item):
            out.append(item)
    return out


def get_allowed_dirs(items, allowed=False, **kwargs):
    allowed = get_allowed_predicate(allowed=allowed)
    out = []
    for fs, item, _ in normalize_items(items, **kwargs):
        if fs.isdir(item) and allowed(item):
            out.append(item)
    return out


# -------------------------------------------------------------
# Filtered sets
# -------------------------------------------------------------
def get_filtered_files(items, allowed=None, files=None, **kwargs):
    items = make_root_list(items)
    allowed = get_allowed_predicate(allowed=allowed)
    files = set(files or [])
    out = []
    for fs, root, _ in normalize_items(items, **kwargs):
        for p in fs.glob_recursive(root, **kwargs):
            if p in files:
                continue
            if allowed(p) and fs.isfile(p):
                out.append(p)
    return out


def get_filtered_dirs(items, allowed=None, dirs=None, **kwargs):
    items = make_root_list(items)
    allowed = get_allowed_predicate(allowed=allowed)
    dirs = set(dirs or [])
    out = []
    for fs, root, _ in normalize_items(items, **kwargs):
        for p in fs.glob_recursive(root, **kwargs):
            if p in dirs:
                continue
            if allowed(p) and fs.isdir(p):
                out.append(p)
    return out


# -------------------------------------------------------------
# Recursive expansion
# -------------------------------------------------------------
def get_all_allowed_files(
    items,
    recursive: bool = True,
    allowed=None,
    fs=None,
    mindepth: int = 0,
    **kwargs,
):
    items = make_root_list(items)
    dirs = get_all_allowed_dirs(items, allowed=allowed, **kwargs)
    files = get_allowed_files(items, allowed=allowed, **kwargs)
    seen = set(files)
    for fs, directory, _ in normalize_items(dirs, **kwargs):
        for p in fs.glob_recursive(directory, **kwargs):
            if p in seen:
                continue
            if allowed and not allowed(p):
                continue
            if fs.isfile(p):
                files.append(p)
                seen.add(p)
    return files


def get_all_allowed_dirs(items, allowed=None, **kwargs):
    items = make_root_list(items)
    allowed = get_allowed_predicate(allowed=allowed)
    out = []
    seen = set()
    for fs, root, _ in normalize_items(items, **kwargs):
        if fs.isdir(root) and allowed(root):
            out.append(root)
            seen.add(root)
        for p in fs.glob_recursive(root, **kwargs):
            if p in seen:
                continue
            if allowed(p) and fs.isdir(p):
                out.append(p)
                seen.add(p)
    return out


# -------------------------------------------------------------
# Unified directory scan
# -------------------------------------------------------------
def get_files_and_dirs(
    directory: str = None,
    cfg: Optional["ScanConfig"] = None,
    allowed_exts: Optional[Set[str]] = False,
    unallowed_exts: Optional[Set[str]] = False,
    exclude_types: Optional[Set[str]] = False,
    exclude_dirs: Optional[List[str]] = False,
    exclude_patterns: Optional[List[str]] = False,
    add=False,
    recursive: bool = True,
    include_files: bool = True,
    roots = None,
    **kwargs
):
    cfg = cfg or define_defaults(
        allowed_exts=allowed_exts,
        unallowed_exts=unallowed_exts,
        exclude_types=exclude_types,
        exclude_dirs=exclude_dirs,
        exclude_patterns=exclude_patterns,
        add=add
    )
    allowed = make_allowed_predicate(cfg)
    items = []
    files = []
    
    # normalize ONCE
    items = make_root_list(directory=directory,roots=roots)
    normalized = list(normalize_items(items, **kwargs))

    for fs, base, _ in normalized:
        
        if recursive:
            items += get_globs(base, recursive=recursive, allowed=allowed, fs=fs, **kwargs)
        else:
            try:
                items += [fs.join(base, name) for name in fs.listdir(base)]
            except Exception:
                pass
    
    # now call the simple os-level filters without re-normalizing
    dirs = [p for p in items if fs.isdir(p) and allowed(p,fs)]
    files = [p for p in items if fs.isfile(p) and allowed(p,fs)] if include_files else []

    return dirs, files


# -------------------------------------------------------------
# Unchanged predicate builder
# -------------------------------------------------------------
def make_allowed_predicate(cfg: ScanConfig) -> Callable[[str], bool]:
    def allowed(path: str,fs=None) -> bool:
        p = str(path)
        basename = os.path.basename(p)
        filename,ext = os.path.splitext(basename)
        fs = fs or LocalFS()
        name = p.lower()
        path_str = p.lower()
        typ = fs.istype(p)
        # A) directory exclusions
        if cfg.exclude_dirs and [dpat for dpat in cfg.exclude_dirs if ((dpat in path_str or fnmatch.fnmatch(name, dpat.lower()))) and (dpat in path_str or fnmatch.fnmatch(name, dpat.lower()))]:
            return False  
                    
                        

        # B) filename pattern exclusions
        if cfg.exclude_patterns and [pat for pat in cfg.exclude_patterns if fnmatch.fnmatch(name, pat.lower())]:
           return False

        # C) extension gates
        if typ == 'file':
            
            if (cfg.allowed_exts and ext not in cfg.allowed_exts) or \
               (cfg.unallowed_exts and ext in cfg.unallowed_exts):
                return False
        return True
    return allowed
